/*
 * main.c
 *
 *  Created on: 2018. 3. 22.
 *      Author: HanCheol Cho
 */


#include "main.h"






int main(void)
{
  hwInit();
  apInit();

  apMain();
}
