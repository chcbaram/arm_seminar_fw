/*
 * hw_def.h
 *
 *  Created on: 2018. 3. 22.
 *      Author: HanCheol Cho
 */

#ifndef SRC_HW_HW_DEF_H_
#define SRC_HW_HW_DEF_H_


#include "def.h"
#include "bsp.h"


#define _HW_DEF_LED_BOOT    _DEF_LED1


#endif /* SRC_HW_HW_DEF_H_ */
